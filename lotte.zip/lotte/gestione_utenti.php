<?php
require 'connessione.php';

$successo = "";
$errore = "";

try {
    $pdo = new PDO($conn_str, $conn_usr, $conn_psw);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Se l'admin ha premuto il pulsante per aggiungere crediti
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id_utente']) && isset($_POST['crediti_add'])) {
        $id_u = intval($_POST['id_utente']);
        $add = intval($_POST['crediti_add']);
        
        if ($add > 0) {
            $stmt_add = $pdo->prepare("UPDATE utente SET crediti = crediti + :add WHERE id = :id");
            $stmt_add->execute(['add' => $add, 'id' => $id_u]);
            $successo = "Aggiunti $add crediti all'utente selezionato!";
        } else {
            $errore = "Inserire un importo valido maggiore di zero.";
        }
    }

    // Recupero la lista di tutti i CLIENTI (escludendo gli admin), ordinati per crediti (i più poveri in cima)
    $stmt = $pdo->query("SELECT id, nome, cognome, email, user_name, crediti FROM utente WHERE ruolo = 'utente' ORDER BY crediti ASC");
    $utenti = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    $errore = "Errore Database: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="it">
<head>
    <meta charset="UTF-8">
    <title>Admin - Gestione Utenti</title>
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <style>
        :root { --blue-dark: #1e3a8a; --blue-light: #3b82f6; }
        body { background-color: #f4f7f9; font-family: 'Segoe UI', sans-serif; }
        .hero { background: linear-gradient(135deg, var(--blue-dark) 0%, var(--blue-light) 100%); color: white; padding: 40px 20px; border-radius: 0 0 40px 40px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); }
        .card-container { background: white; border-radius: 20px; padding: 25px; margin-top: -30px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); }
        .low-credits { color: #dc3545; font-weight: bold; }
        .high-credits { color: #28a745; font-weight: bold; }
        .form-inline { display: flex; gap: 10px; align-items: center; justify-content: flex-end; }
    </style>
</head>
<body>

    <header class="hero w3-center">
        <h1 class="w3-xlarge"><b><i class="fa fa-users"></i> Gestione Utenti & Crediti</b></h1>
        <p class="w3-opacity">Controlla i saldi e ricarica i portafogli dei giocatori</p>
    </header>

    <div class="w3-content" style="max-width:1200px; padding: 32px 16px;">
        <div class="card-container">
            
            <div class="w3-margin-bottom">
                <a href="index.html" class="w3-button w3-light-grey w3-round-large w3-small"><i class="fa fa-arrow-left"></i> Torna alle Lotterie</a>
            </div>

            <?php if ($errore): ?>
                <div class="w3-panel w3-red w3-round-large w3-padding"><?= $errore ?></div>
            <?php endif; ?>
            <?php if ($successo): ?>
                <div class="w3-panel w3-green w3-round-large w3-padding"><?= $successo ?></div>
            <?php endif; ?>

            <div class="w3-responsive">
                <table class="w3-table w3-striped w3-bordered w3-hoverable w3-small">
                    <thead>
                        <tr class="w3-light-grey">
                            <th>ID</th>
                            <th>NOME & COGNOME</th>
                            <th>USERNAME</th>
                            <th>EMAIL</th>
                            <th>SALDO CREDITI</th>
                            <th class="w3-right-align">RICARICA CREDITI</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (count($utenti) === 0): ?>
                            <tr><td colspan="6" class="w3-center w3-padding-32">Nessun utente trovato.</td></tr>
                        <?php endif; ?>

                        <?php foreach ($utenti as $u): ?>
                        <tr>
                            <td>#<?= $u['id'] ?></td>
                            <td><b><?= htmlspecialchars($u['nome']) ?> <?= htmlspecialchars($u['cognome']) ?></b></td>
                            <td><?= htmlspecialchars($u['user_name']) ?></td>
                            <td><?= htmlspecialchars($u['email']) ?></td>
                            <td>
                                <span class="<?= $u['crediti'] < 10 ? 'low-credits' : 'high-credits' ?>">
                                    <?= $u['crediti'] ?> <i class="fa fa-coins"></i>
                                </span>
                            </td>
                            <td>
                                <form method="POST" action="gestione_utenti.php" class="form-inline">
                                    <input type="hidden" name="id_utente" value="<?= $u['id'] ?>">
                                    <input class="w3-input w3-border w3-round" type="number" name="crediti_add" min="1" placeholder="+ Importo" required style="width: 100px; padding: 5px;">
                                    <button type="submit" class="w3-button w3-green w3-round" title="Ricarica Account">
                                        <i class="fa fa-plus"></i> Aggiungi
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        </div>
    </div>

</body>
</html>