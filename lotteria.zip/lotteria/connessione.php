<?php
    // parametri connessione al database
    $conn_server = 'localhost';
    $conn_db = 'lotteria_db';
    $conn_usr = 'root';
    $conn_psw = '';

    $conn_str = 'mysql:host=' . $conn_server . ';dbname=' . $conn_db;
?>
